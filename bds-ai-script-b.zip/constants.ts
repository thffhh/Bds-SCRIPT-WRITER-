
import { AppSettings } from './types';

export const DEFAULT_SETTINGS: AppSettings = {
  maxUploadSizeGB: 50,
  maxVideoLengthHours: 3,
  dailyAiLimit: 100,
  characterDetectionEnabled: true,
  emotionStrictness: 'high',
  googleVerifyEnabled: true,
  geminiModel: 'gemini-3-flash-preview',
  githubRepoUrl: '',
  netlifyDashboardUrl: '',
};

export const SECRET_TAP_COUNT = 5;
export const SECRET_LONG_PRESS_MS = 7000;
