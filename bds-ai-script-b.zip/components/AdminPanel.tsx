
import React, { useState } from 'react';
import { AppSettings } from '../types';
import { 
  Shield, HardDrive, RefreshCcw, X, Trash2, Database, 
  CheckCircle2, AlertTriangle, Globe, ExternalLink, 
  Zap, Terminal, Smartphone, Github, Activity, Cloud, Link
} from 'lucide-react';

interface AdminPanelProps {
  settings: AppSettings;
  setSettings: (s: AppSettings) => void;
  onClose: () => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ settings, setSettings, onClose }) => {
  const isEnvActive = !!process.env.API_KEY;
  const [activeTab, setActiveTab] = useState<'status' | 'links' | 'limits'>('status');

  const handleChange = (key: keyof AppSettings, value: any) => {
    setSettings({ ...settings, [key]: value });
  };

  const clearHistory = () => {
    if (confirm("আপনি কি নিশ্চিত যে সব জেনারেট করা স্ক্রিপ্ট ডিলিট করবেন?")) {
      localStorage.removeItem('bds_script_history');
      window.location.reload();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-xl flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-2xl rounded-[3rem] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-8 border-b border-slate-800 flex justify-between items-center bg-slate-900/50">
          <div className="flex items-center gap-4 text-indigo-400">
            <div className="p-3 bg-indigo-500/10 rounded-2xl border border-indigo-500/20">
              <Shield size={28} />
            </div>
            <div>
              <h2 className="text-2xl font-black tracking-tight text-white uppercase">BDS Command Center</h2>
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.2em]">Mobile Optimized Setup</p>
            </div>
          </div>
          <button onClick={onClose} className="p-3 hover:bg-slate-800 rounded-2xl transition-all text-slate-400 hover:text-white">
            <X size={24} />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-800 px-8 py-2 gap-4 overflow-x-auto no-scrollbar">
          {[
            { id: 'status', label: 'Status', icon: Activity },
            { id: 'links', label: 'Connections', icon: Link },
            { id: 'limits', label: 'System', icon: Database },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === tab.id ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-800'}`}
            >
              <tab.icon size={14} /> {tab.label}
            </button>
          ))}
        </div>

        <div className="p-10 overflow-y-auto custom-scrollbar flex-1 space-y-12">
          
          {/* Tab Content: Status */}
          {activeTab === 'status' && (
            <section className="space-y-8 animate-in fade-in slide-in-from-bottom-4">
              <div className={`p-8 rounded-[2.5rem] border ${isEnvActive ? 'bg-green-500/[0.02] border-green-500/20' : 'bg-red-500/[0.02] border-red-500/20'} flex flex-col items-center text-center space-y-4`}>
                <div className={`p-5 rounded-full ${isEnvActive ? 'bg-green-500/10 text-green-500' : 'bg-red-500/10 text-red-500 animate-pulse'}`}>
                  {isEnvActive ? <CheckCircle2 size={48} /> : <AlertTriangle size={48} />}
                </div>
                <div>
                  <p className="text-xl font-black text-white">
                    {isEnvActive ? 'GLOBAL SYSTEM LIVE' : 'API CONFIG REQUIRED'}
                  </p>
                  <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                    {isEnvActive 
                      ? 'আপনার সিস্টেম এখন পুরোপুরি সচল। পৃথিবীর যেকোনো প্রান্ত থেকে ভিডিও টু স্ক্রিপ্ট কাজ করবে।' 
                      : 'Gemini API Key পাওয়া যায়নি। নিচের স্টেপগুলো ফলো করে ফোনে রি-ডেপ্লয় করুন।'}
                  </p>
                </div>
              </div>

              {!isEnvActive && (
                <div className="p-8 bg-indigo-600/5 border border-indigo-500/20 rounded-[2.5rem] space-y-6">
                  <div className="flex items-center gap-3 border-b border-indigo-500/10 pb-4">
                    <Smartphone className="text-indigo-400" size={20} />
                    <p className="text-sm font-black text-white uppercase tracking-widest">Mobile Deploy Shortcut</p>
                  </div>
                  <div className="space-y-5">
                    <div className="flex items-start gap-4">
                      <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-indigo-400 font-bold shrink-0">১</div>
                      <p className="text-xs text-slate-400 leading-relaxed">আপনার হোস্টিং ড্যাশবোর্ড (Netlify/Vercel) এ গিয়ে <code className="bg-indigo-500/20 text-indigo-300 px-1 py-0.5 rounded font-mono">API_KEY</code> সেট করুন।</p>
                    </div>
                    <div className="flex items-start gap-4">
                      <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-indigo-400 font-bold shrink-0">২</div>
                      <p className="text-xs text-slate-400 leading-relaxed">ফোনে রি-ডেপ্লয় বাটন না থাকলে <b>GitHub</b> বাটনে ক্লিক করে কোড এডিটরে গিয়ে ফাইলে একটা স্পেস দিয়ে সেভ করুন।</p>
                    </div>
                  </div>
                </div>
              )}
            </section>
          )}

          {/* Tab Content: Links */}
          {activeTab === 'links' && (
            <section className="space-y-8 animate-in fade-in slide-in-from-bottom-4">
              <div className="space-y-4">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Your GitHub Repo URL</label>
                <div className="relative">
                  <input 
                    type="text" 
                    value={settings.githubRepoUrl}
                    onChange={(e) => handleChange('githubRepoUrl', e.target.value)}
                    placeholder="https://github.com/user/repo"
                    className="w-full bg-black/50 border border-slate-800 rounded-2xl pl-12 pr-5 py-4 text-white focus:ring-2 focus:ring-indigo-500 outline-none font-medium text-sm"
                  />
                  <Github className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600" size={20} />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <a 
                  href={settings.githubRepoUrl || "https://github.com"} 
                  target="_blank" 
                  className="p-6 bg-slate-800/50 border border-slate-700 rounded-3xl hover:border-indigo-500/50 transition-all flex items-center gap-4 group"
                >
                  <div className="p-3 bg-white/5 rounded-2xl group-hover:bg-indigo-500/20 transition-colors">
                    <Github size={24} className="text-white" />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-white">GitHub Edit</p>
                    <p className="text-[10px] text-slate-500 font-black uppercase">Instant Access</p>
                  </div>
                </a>

                <a 
                  href="https://app.netlify.com" 
                  target="_blank" 
                  className="p-6 bg-slate-800/50 border border-slate-700 rounded-3xl hover:border-teal-500/50 transition-all flex items-center gap-4 group"
                >
                  <div className="p-3 bg-white/5 rounded-2xl group-hover:bg-teal-500/20 transition-colors">
                    <Cloud size={24} className="text-teal-400" />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-white">Netlify Dashboard</p>
                    <p className="text-[10px] text-slate-500 font-black uppercase">Env Settings</p>
                  </div>
                </a>
              </div>
            </section>
          )}

          {/* Tab Content: Limits & Storage */}
          {activeTab === 'limits' && (
            <section className="space-y-8 animate-in fade-in slide-in-from-bottom-4">
              <div className="p-6 bg-slate-800/30 rounded-3xl border border-slate-800 space-y-4">
                <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest">Max File Size (GB)</label>
                <input 
                  type="number" 
                  value={settings.maxUploadSizeGB}
                  onChange={(e) => handleChange('maxUploadSizeGB', Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-5 py-3 text-white focus:ring-2 focus:ring-indigo-500 outline-none font-bold"
                />
              </div>

              <div className="p-6 bg-slate-800/30 rounded-3xl border border-slate-800 flex items-center justify-between">
                <div>
                  <p className="text-sm font-bold text-white">Database Reset</p>
                  <p className="text-[10px] text-slate-500 uppercase font-black">Clear all local scripts</p>
                </div>
                <button 
                  onClick={clearHistory}
                  className="p-3 bg-red-500/10 hover:bg-red-500/20 text-red-500 rounded-xl transition-all border border-red-500/20"
                >
                  <Trash2 size={20} />
                </button>
              </div>
            </section>
          )}

        </div>

        {/* Footer Actions */}
        <div className="p-8 border-t border-slate-800 bg-slate-900/50">
          <button 
            onClick={onClose} 
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-black py-5 rounded-[2rem] transition-all shadow-2xl shadow-indigo-600/20 active:scale-95 flex items-center justify-center gap-3 uppercase tracking-widest text-sm"
          >
            <RefreshCcw size={20} /> Save & Exit System
          </button>
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;
