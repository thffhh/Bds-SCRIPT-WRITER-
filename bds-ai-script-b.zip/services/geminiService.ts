
import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult, AppSettings } from "../types";

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    // API key must be obtained exclusively from the environment variable process.env.API_KEY
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      throw new Error("API_KEY environment variable is not configured. Please set it in your hosting provider's dashboard.");
    }
    this.ai = new GoogleGenAI({ apiKey });
  }

  async analyzeVideoContent(
    fileData: string, 
    mimeType: string, 
    settings: AppSettings
  ): Promise<AnalysisResult> {
    const prompt = `
      ভিডিওটি বিশ্লেষণ করুন এবং একটি বিস্তারিত সিনেমাটিক স্ক্রিপ্ট তৈরি করুন।
      আপনার আউটপুট অবশ্যই নিচের নিয়মগুলো মেনে চলবে:
      ১. সংলাপ (Dialogue) এবং আবেগ (Emotion) সম্পূর্ণ বাংলায় হতে হবে।
      ২. চরিত্রদের প্রতিটি সূক্ষ্ম শব্দ যেমন: দীর্ঘশ্বাস (নিশ্বাস), উহ (uh), আহ (ahh), হাঁপানো, বা কান্নার শব্দ সংলাপে ব্র্যাকেটের মধ্যে বা সরাসরি যোগ করুন। 
      ৩. ইমোশন বা আবেগগুলো বিস্তারিতভাবে বর্ণনা করুন।
      ৪. আউটপুট অবশ্যই শুদ্ধ JSON হতে হবে।
    `;

    try {
      const response = await this.ai.models.generateContent({
        model: settings.geminiModel,
        contents: {
          parts: [
            { text: prompt },
            { inlineData: { data: fileData, mimeType } }
          ]
        },
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              script: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    character: { type: Type.STRING },
                    emotion: { type: Type.STRING },
                    dialogue: { type: Type.STRING },
                    timestamp: { type: Type.STRING }
                  },
                  required: ["character", "emotion", "dialogue", "timestamp"]
                }
              },
              accuracy: { type: Type.NUMBER },
              verificationPassed: { type: Type.BOOLEAN }
            },
            required: ["script", "accuracy", "verificationPassed"]
          }
        }
      });

      // Directly accessing the .text property from GenerateContentResponse
      const result = JSON.parse(response.text || '{}');
      return result as AnalysisResult;
    } catch (error: any) {
      console.error("Gemini Error:", error);
      throw new Error(error.message || "স্ক্রিপ্ট তৈরি করতে সমস্যা হয়েছে। আপনার সার্ভার কনফিগারেশন চেক করুন।");
    }
  }
}