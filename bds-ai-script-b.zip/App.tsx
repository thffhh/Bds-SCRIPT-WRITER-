
import React, { useState, useEffect } from 'react';
import { Shield, FileVideo, Upload, Cpu, Zap, AlertCircle, Info, Lock, History, Trash2, CloudOff, RefreshCcw } from 'lucide-react';
import AdminPanel from './components/AdminPanel';
import ScriptDisplay from './components/ScriptDisplay';
import { GeminiService } from './services/geminiService';
import { DEFAULT_SETTINGS, SECRET_TAP_COUNT } from './constants';
import { AppSettings, ProcessingState, AnalysisResult, HistoryItem } from './types';

const App: React.FC = () => {
  const isConfigured = !!process.env.API_KEY;
  
  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem('bds_ai_settings');
    return saved ? JSON.parse(saved) : DEFAULT_SETTINGS;
  });

  const [history, setHistory] = useState<HistoryItem[]>(() => {
    const saved = localStorage.getItem('bds_script_history');
    return saved ? JSON.parse(saved) : [];
  });

  const [isAdmin, setIsAdmin] = useState(false);
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [adminKeyInput, setAdminKeyInput] = useState('');
  const [logoTaps, setLogoTaps] = useState(0);
  
  const [processing, setProcessing] = useState<ProcessingState>({
    isUploading: false,
    isAnalyzing: false,
    progress: 0,
    status: '',
    error: null,
  });
  const [result, setResult] = useState<AnalysisResult | null>(null);

  useEffect(() => {
    localStorage.setItem('bds_ai_settings', JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem('bds_script_history', JSON.stringify(history));
  }, [history]);

  const handleLogoClick = () => {
    const newTaps = logoTaps + 1;
    if (newTaps >= SECRET_TAP_COUNT) {
      setShowAdminLogin(true);
      setLogoTaps(0);
    } else {
      setLogoTaps(newTaps);
      setTimeout(() => setLogoTaps(0), 2000);
    }
  };

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminKeyInput === 'admin@gemini') {
      setIsAdmin(true);
      setShowAdminLogin(false);
      setAdminKeyInput('');
    } else {
      alert('ভুল অ্যাডমিন পাসওয়ার্ড!');
    }
  };

  const deleteHistoryItem = (id: string) => {
    setHistory(history.filter(item => item.id !== id));
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!isConfigured) {
      setProcessing(p => ({ ...p, error: "System Error: API_KEY পাওয়া যায়নি। অ্যাডমিন প্যানেল চেক করুন।" }));
      return;
    }

    if (file.size > settings.maxUploadSizeGB * 1024 * 1024 * 1024) {
      setProcessing(p => ({ ...p, error: `ফাইল সাইজ অনেক বড়! সর্বোচ্চ ${settings.maxUploadSizeGB}GB অনুমোদিত।` }));
      return;
    }

    setProcessing({
      isUploading: true,
      isAnalyzing: false,
      progress: 0,
      status: 'ভিডিও আপলোড হচ্ছে...',
      error: null
    });
    setResult(null);

    // Simulated upload progress
    for (let i = 0; i <= 100; i += 20) {
      await new Promise(r => setTimeout(r, 200));
      setProcessing(p => ({ ...p, progress: i }));
    }

    setProcessing(p => ({ 
      ...p, 
      isUploading: false, 
      isAnalyzing: true, 
      progress: 10,
      status: 'BDS AI স্ক্রিপ্ট প্রসেস করছে...' 
    }));

    try {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = async () => {
        const base64Data = (reader.result as string).split(',')[1];
        
        // Always instantiate GeminiService here to pick up potentially updated settings/key
        const gemini = new GeminiService();
        const analysis = await gemini.analyzeVideoContent(base64Data, file.type, settings);
        
        setResult(analysis);
        
        const newItem: HistoryItem = {
          id: Date.now().toString(),
          date: new Date().toLocaleString(),
          fileName: file.name,
          result: analysis
        };
        setHistory([newItem, ...history].slice(0, 50));
        
        setProcessing(p => ({ ...p, isAnalyzing: false, progress: 100, status: 'সম্পন্ন হয়েছে!' }));
      };
    } catch (err: any) {
      setProcessing(p => ({ 
        ...p, 
        error: err.message || "প্রসেসিং ব্যর্থ হয়েছে।", 
        isAnalyzing: false 
      }));
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-200">
      <header className="h-20 border-b border-slate-800 flex items-center justify-between px-6 md:px-12 bg-slate-900/40 backdrop-blur-xl sticky top-0 z-40">
        <div onClick={handleLogoClick} className="flex items-center gap-3 cursor-pointer group">
          <div className="p-2 bg-indigo-600 rounded-xl group-hover:rotate-12 transition-all duration-300">
            <Cpu className="text-white" size={24} />
          </div>
          <div>
            <h1 className="text-xl font-black text-white uppercase tracking-tighter">BDS AI <span className="text-indigo-500">SCRIPT</span></h1>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {isConfigured ? (
            <div className="flex items-center gap-2 px-4 py-1.5 bg-green-500/10 border border-green-500/20 rounded-full">
              <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
              <span className="text-[10px] font-black text-green-500 uppercase tracking-widest">Global Live</span>
            </div>
          ) : (
            <div className="flex items-center gap-2 px-4 py-1.5 bg-amber-500/10 border border-amber-500/20 rounded-full">
              <CloudOff size={12} className="text-amber-500" />
              <span className="text-[10px] font-black text-amber-500 uppercase tracking-widest">Configuration Required</span>
            </div>
          )}
          {isAdmin && (
            <button onClick={() => setShowAdminLogin(true)} className="p-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-full transition-all shadow-lg shadow-indigo-600/20">
              <Shield size={18} />
            </button>
          )}
        </div>
      </header>

      <main className="flex-1 max-w-5xl w-full mx-auto px-6 py-12 md:py-24 space-y-24">
        {/* Hero Section */}
        <section className="text-center space-y-8">
          <div className="inline-flex items-center gap-3 px-6 py-2.5 rounded-full bg-indigo-500/5 border border-indigo-500/20 text-indigo-400 text-[10px] font-black tracking-widest uppercase">
            <Zap size={14} className="fill-current" /> Cinematic Video To Script Converter
          </div>
          <h2 className="text-6xl md:text-8xl font-black text-white tracking-tight leading-[0.9]">
            ভিডিও দিন, <br />
            <span className="text-slate-700">স্ক্রিপ্ট নিন।</span>
          </h2>
          <p className="max-w-xl mx-auto text-slate-500 text-sm font-medium leading-relaxed">
            মুহূর্তেই AI এর মাধ্যমে আপনার ভিডিও থেকে সংলাপ, আবেগ এবং প্রতিটি মুহূর্তের বর্ণনা বাংলা স্ক্রিপ্টে রূপান্তর করুন।
          </p>
        </section>

        {/* Upload Container */}
        <section className="relative max-w-3xl mx-auto">
          {!isConfigured && (
            <div className="absolute inset-0 z-20 bg-slate-950/80 backdrop-blur-md rounded-[4rem] flex flex-col items-center justify-center p-12 text-center space-y-6 border border-slate-800">
              <div className="w-20 h-20 bg-amber-500/10 rounded-full flex items-center justify-center text-amber-500 border border-amber-500/20">
                <AlertCircle size={40} />
              </div>
              <div className="space-y-2">
                <h3 className="text-2xl font-black text-white uppercase">সিস্টেম প্রস্তুত নয়</h3>
                <p className="text-sm text-slate-400">অ্যাডমিন ড্যাশবোর্ডে গিয়ে API_KEY সেট করুন। <br/>গাইডলাইন দেখতে লোগোতে ৫ বার ট্যাপ করুন।</p>
              </div>
            </div>
          )}
          
          <div className="group relative bg-slate-900/40 border-2 border-dashed border-slate-800 rounded-[4rem] p-20 transition-all hover:border-indigo-500/40 hover:bg-indigo-500/[0.02] cursor-pointer overflow-hidden shadow-2xl">
            <input 
              type="file" 
              accept="video/*" 
              onChange={handleFileUpload}
              className="absolute inset-0 opacity-0 cursor-pointer z-10"
              disabled={processing.isUploading || processing.isAnalyzing || !isConfigured}
            />
            <div className="flex flex-col items-center text-center space-y-8 relative z-0">
              <div className="w-24 h-24 bg-slate-800 rounded-[2.5rem] flex items-center justify-center text-slate-500 group-hover:text-indigo-400 group-hover:scale-110 transition-all duration-700 border border-slate-700 group-hover:border-indigo-500/40 shadow-xl">
                <FileVideo size={40} />
              </div>
              <div className="space-y-3">
                <p className="text-3xl font-black text-white">ভিডিও ফাইলটি এখানে আনুন</p>
                <p className="text-xs text-slate-500 font-black uppercase tracking-[0.2em]">MP4, MOV (MAX {settings.maxUploadSizeGB}GB)</p>
              </div>
            </div>
          </div>

          {(processing.isUploading || processing.isAnalyzing) && (
            <div className="mt-12 bg-slate-900 border border-slate-800 rounded-[3rem] p-10 shadow-3xl animate-in fade-in zoom-in duration-500">
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-indigo-500/10 rounded-2xl flex items-center justify-center text-indigo-400 animate-spin">
                    {/* Use the imported RefreshCcw icon */}
                    <RefreshCcw size={24} />
                  </div>
                  <p className="text-sm font-black text-white uppercase tracking-[0.2em]">{processing.status}</p>
                </div>
                <span className="text-2xl font-black text-indigo-500 font-mono">{processing.progress}%</span>
              </div>
              <div className="h-2.5 w-full bg-slate-800 rounded-full overflow-hidden p-0.5 border border-slate-700/50">
                <div 
                  className="h-full bg-indigo-500 rounded-full transition-all duration-700 shadow-[0_0_20px_rgba(99,102,241,0.5)]" 
                  style={{ width: `${processing.progress}%` }} 
                />
              </div>
            </div>
          )}

          {processing.error && (
            <div className="mt-8 p-6 bg-red-500/5 border border-red-500/20 rounded-[2.5rem] flex items-center gap-5 text-red-400">
              <AlertCircle size={24} />
              <p className="font-bold text-sm leading-relaxed">{processing.error}</p>
            </div>
          )}
        </section>

        {/* Results */}
        {result && (
          <section className="animate-in fade-in slide-in-from-bottom-16 duration-1000">
            <ScriptDisplay script={result.script} accuracy={result.accuracy} />
          </section>
        )}

        {/* Local History Database */}
        {history.length > 0 && (
          <section className="space-y-10 pt-24 border-t border-slate-900">
            <div className="flex items-center gap-5">
              <div className="p-3 bg-slate-800 rounded-2xl text-indigo-500">
                <History size={24} />
              </div>
              <div>
                <h3 className="text-3xl font-black text-white uppercase tracking-tight">Recent Database</h3>
                <p className="text-[10px] text-slate-600 font-black uppercase tracking-widest">Cached Local History</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {history.map((item) => (
                <div key={item.id} className="bg-slate-900/40 border border-slate-800 rounded-[2.5rem] p-8 hover:border-indigo-500/30 transition-all group hover:bg-slate-900/60">
                  <div className="flex justify-between items-start">
                    <div className="space-y-2">
                      <p className="text-[10px] text-indigo-500 font-black uppercase tracking-[0.2em]">{item.date}</p>
                      <h4 className="text-lg font-bold text-white truncate max-w-[220px]">{item.fileName}</h4>
                      <div className="flex items-center gap-3 text-[10px] font-black text-slate-600 uppercase tracking-widest">
                        <span>{item.result.script.length} Lines</span>
                        <span className="w-1 h-1 bg-slate-800 rounded-full" />
                        <span>{(item.result.accuracy * 100).toFixed(0)}% Match</span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => setResult(item.result)} 
                        className="p-3 bg-indigo-600/10 hover:bg-indigo-600 text-indigo-400 hover:text-white rounded-2xl transition-all shadow-lg"
                      >
                        <Info size={20} />
                      </button>
                      <button 
                        onClick={() => deleteHistoryItem(item.id)} 
                        className="p-3 bg-slate-800 hover:bg-red-500/10 text-slate-600 hover:text-red-500 rounded-2xl transition-all"
                      >
                        <Trash2 size={20} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}
      </main>

      <footer className="py-16 border-t border-slate-900 flex flex-col items-center gap-6">
        <div 
          onContextMenu={(e) => { e.preventDefault(); setShowAdminLogin(true); }} 
          className="px-6 py-2 bg-slate-900/50 border border-slate-800 rounded-full text-[10px] font-black text-slate-800 tracking-widest hover:text-slate-600 transition-colors cursor-help uppercase"
        >
          System Version: 3.1.0_Global_Ready
        </div>
      </footer>

      {showAdminLogin && (
        isAdmin ? (
          <AdminPanel settings={settings} setSettings={setSettings} onClose={() => setShowAdminLogin(false)} />
        ) : (
          <div className="fixed inset-0 z-[60] bg-slate-950/98 backdrop-blur-3xl flex items-center justify-center p-6">
            <form onSubmit={handleAdminLogin} className="bg-slate-900 border border-slate-800 w-full max-w-sm rounded-[3.5rem] p-12 space-y-10 shadow-4xl animate-in fade-in zoom-in duration-300">
              <div className="flex flex-col items-center gap-8 text-center">
                <div className="w-24 h-24 bg-indigo-500/10 rounded-[2.5rem] flex items-center justify-center text-indigo-500 border border-indigo-500/20 shadow-xl">
                  <Lock size={44} />
                </div>
                <div className="space-y-2">
                  <h2 className="text-3xl font-black text-white uppercase tracking-tighter">BDS Master</h2>
                  <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest">Authentication Required</p>
                </div>
              </div>
              <div className="space-y-4">
                <input 
                  type="password" 
                  value={adminKeyInput}
                  onChange={(e) => setAdminKeyInput(e.target.value)}
                  placeholder="Password"
                  className="w-full bg-black/50 border border-slate-800 rounded-2xl px-6 py-4 text-white text-center outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all font-mono"
                  autoFocus
                />
                <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-black py-4 rounded-2xl shadow-xl shadow-indigo-600/20 transition-all active:scale-95 uppercase tracking-widest text-xs">
                  Authorize Access
                </button>
                <button type="button" onClick={() => setShowAdminLogin(false)} className="w-full text-[10px] font-black text-slate-600 uppercase tracking-widest hover:text-slate-400 transition-colors pt-2">
                  Dismiss
                </button>
              </div>
            </form>
          </div>
        )
      )}
    </div>
  );
};

export default App;
