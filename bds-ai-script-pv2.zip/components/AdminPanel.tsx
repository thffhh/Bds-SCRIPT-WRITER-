
import React, { useState, useEffect } from 'react';
import { AppSettings } from '../types';
import { 
  X, Trash2, Database, CheckCircle2, AlertTriangle, 
  Zap, Github, Activity, Cloud, Key, ArrowRight, Share2, 
  Lock, RefreshCw, Loader2, HardDrive, Globe, Users, ShieldAlert,
  ServerCrash, Rocket, Info, ExternalLink
} from 'lucide-react';

// Using direct CDN import to fix the "Could not resolve ./libsodium.mjs" build error on Netlify
import sodium from 'https://esm.sh/libsodium-wrappers@0.7.15?bundle';

interface AdminPanelProps {
  settings: AppSettings;
  setSettings: (s: AppSettings) => void;
  onClose: () => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ settings, setSettings, onClose }) => {
  const [activeTab, setActiveTab] = useState<'status' | 'cloud' | 'system' | 'users'>('cloud');
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState<{ type: 'success' | 'error' | null, msg: string }>({ type: null, msg: '' });

  const handleChange = (key: keyof AppSettings, value: any) => {
    setSettings({ ...settings, [key]: value });
  };

  const encryptSecret = async (publicKey: string, secretValue: string) => {
    await sodium.ready;
    const binKey = sodium.from_base64(publicKey, sodium.base64_variants.ORIGINAL);
    const binSec = sodium.from_string(secretValue);
    const encBytes = sodium.crypto_box_seal(binSec, binKey);
    return sodium.to_base64(encBytes, sodium.base64_variants.ORIGINAL);
  };

  const pushSecret = async (owner: string, repo: string, name: string, value: string, token: string, pkData: any) => {
    const encryptedValue = await encryptSecret(pkData.key, value);
    const res = await fetch(`https://api.github.com/repos/${owner}/${repo}/actions/secrets/${name}`, {
      method: 'PUT',
      headers: {
        'Authorization': `token ${token}`,
        'Accept': 'application/vnd.github.v3+json'
      },
      body: JSON.stringify({
        encrypted_value: encryptedValue,
        key_id: pkData.key_id
      })
    });
    return res.ok;
  };

  const handleGlobalSync = async () => {
    if (!settings.githubToken || !settings.githubRepoUrl || !settings.masterApiKey) {
      setSyncStatus({ type: 'error', msg: 'সবগুলো ঘর (Key, Token, Repo) পূরণ করুন!' });
      return;
    }

    setIsSyncing(true);
    setSyncStatus({ type: null, msg: '' });

    try {
      // Robust Repo Path Parsing
      let repoInput = settings.githubRepoUrl.trim();
      // Remove https://github.com/ if present
      repoInput = repoInput.replace(/https?:\/\/github\.com\//, '');
      // Remove trailing slashes and .git
      repoInput = repoInput.replace(/\/$/, '').replace(/\.git$/, '');
      
      const parts = repoInput.split('/');
      if (parts.length < 2) {
        throw new Error("Repo Path সঠিক নয়। এটি 'username/reponame' ফরম্যাটে হতে হবে।");
      }
      
      const owner = parts[parts.length - 2];
      const repo = parts[parts.length - 1];

      const token = settings.githubToken.trim();
      const headers = {
        'Authorization': `token ${token}`,
        'Accept': 'application/vnd.github.v3+json'
      };

      // 1. Get Public Key for encryption
      const pkRes = await fetch(`https://api.github.com/repos/${owner}/${repo}/actions/secrets/public-key`, { headers });
      
      if (pkRes.status === 404) throw new Error(`গিটহাব রিপোজিটরি '${owner}/${repo}' পাওয়া যায়নি। স্পেলিং চেক করুন।`);
      if (pkRes.status === 401) throw new Error("GitHub Token ভুল। দয়া করে নতুন টোকেন দিয়ে চেষ্টা করুন।");
      if (pkRes.status === 403) throw new Error("টোকেনে পারমিশন নেই! টোকেন তৈরির সময় অবশ্যই 'repo' বক্সে টিক দিতে হবে।");
      
      if (!pkRes.ok) {
        const errData = await pkRes.json();
        throw new Error(errData.message || "GitHub কানেকশন এরর।");
      }
      
      const pkData = await pkRes.json();

      // 2. Push the master key as API_KEY secret to GitHub
      const apiSuccess = await pushSecret(owner, repo, 'API_KEY', settings.masterApiKey.trim(), token, pkData);
      
      if (!apiSuccess) throw new Error("গিটহাব সিক্রেট সেভ করতে ব্যর্থ হয়েছে। পারমিশন চেক করুন।");

      setSyncStatus({ 
        type: 'success', 
        msg: `সাফল্য! '${owner}/${repo}' রিপোজিটরিতে API_KEY সেভ হয়েছে। আপনার সাইটটি এখন রি-ডিপ্লয় (Re-deploy) করুন, তাহলেই সবাই আপনার কী ব্যবহার করতে পারবে।` 
      });

      localStorage.setItem('bds_ai_settings', JSON.stringify(settings));

    } catch (err: any) {
      setSyncStatus({ type: 'error', msg: err.message || 'অজানা একটি সমস্যা হয়েছে।' });
    } finally {
      setIsSyncing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-xl flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-3xl rounded-[4rem] shadow-3xl overflow-hidden flex flex-col max-h-[90vh] my-8">
        
        <div className="p-8 border-b border-slate-800 flex justify-between items-center bg-slate-900/50">
          <div className="flex items-center gap-4 text-indigo-400">
            <div className="p-3 bg-indigo-500/10 rounded-2xl border border-indigo-500/20">
              <Globe size={28} />
            </div>
            <div>
              <h2 className="text-2xl font-black tracking-tight text-white uppercase">Global Control</h2>
              <p className="text-[9px] text-slate-500 font-black uppercase tracking-[0.2em]">Master Deployment Center</p>
            </div>
          </div>
          <button onClick={onClose} className="p-3 bg-slate-800 hover:bg-slate-700 rounded-xl transition-all text-slate-400 hover:text-white">
            <X size={20} />
          </button>
        </div>

        <div className="flex border-b border-slate-800 px-8 py-3 gap-2 bg-slate-900/30 overflow-x-auto no-scrollbar">
          {[
            { id: 'cloud', label: 'Global Activation', icon: Cloud },
            { id: 'users', label: 'Security', icon: ShieldAlert },
            { id: 'system', label: 'Quotas', icon: HardDrive },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-3 px-5 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shrink-0 border ${activeTab === tab.id ? 'bg-indigo-600 text-white border-indigo-500 shadow-lg shadow-indigo-600/20' : 'text-slate-500 hover:bg-slate-800 border-transparent'}`}
            >
              <tab.icon size={14} /> {tab.label}
            </button>
          ))}
        </div>

        <div className="p-8 overflow-y-auto custom-scrollbar flex-1 space-y-8">
          
          {activeTab === 'cloud' && (
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4">
              <div className="p-6 bg-indigo-500/5 border border-indigo-500/10 rounded-3xl space-y-4">
                <div className="flex items-start gap-5">
                  <Rocket className="text-indigo-400 shrink-0" size={24} />
                  <div>
                    <p className="text-xs font-bold text-white mb-1 uppercase tracking-tight">সবার জন্য এপিআই কী সক্রিয় করুন</p>
                    <p className="text-[10px] text-slate-400 leading-relaxed font-medium">
                      এটি আপনার এপিআই কী-টিকে আপনার গিটহাব রিপোজিটরির <b>Secrets</b>-এ পুশ করবে। 
                    </p>
                  </div>
                </div>
                
                <div className="pt-4 border-t border-indigo-500/10 grid grid-cols-1 gap-3">
                   <div className="flex items-center gap-3 text-[9px] text-indigo-300 font-black uppercase tracking-widest">
                     <Info size={14} /> GitHub Token-এ যা যা লাগবে:
                   </div>
                   <ul className="text-[9px] text-slate-500 space-y-1 list-disc list-inside px-1">
                     <li>Classic Token ব্যবহার করুন।</li>
                     <li>অবশ্যই <span className="text-white">"repo"</span> বক্সে টিক দিন।</li>
                     <li>অন্যান্য পারমিশন দরকার নেই।</li>
                   </ul>
                </div>
              </div>

              <div className="space-y-6">
                <div className="space-y-3">
                  <label className="text-[10px] font-black text-indigo-400 uppercase tracking-widest ml-1 flex items-center gap-2">
                    <Key size={12} /> Master Gemini API Key
                  </label>
                  <input 
                    type="password" 
                    value={settings.masterApiKey || ''}
                    onChange={(e) => handleChange('masterApiKey', e.target.value)}
                    className="w-full bg-black border border-slate-800 rounded-xl px-5 py-4 text-white focus:ring-2 focus:ring-indigo-500/50 outline-none font-mono text-sm"
                    placeholder="AIzaSy..."
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div className="space-y-3">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">GitHub Repo Path</label>
                    <input 
                      type="text" 
                      value={settings.githubRepoUrl || ''}
                      onChange={(e) => handleChange('githubRepoUrl', e.target.value)}
                      className="w-full bg-black border border-slate-800 rounded-xl px-5 py-4 text-white focus:ring-2 focus:ring-indigo-500/50 outline-none text-xs"
                      placeholder="username/reponame"
                    />
                  </div>
                  <div className="space-y-3">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">GitHub Classic Token</label>
                    <input 
                      type="password" 
                      value={settings.githubToken || ''}
                      onChange={(e) => handleChange('githubToken', e.target.value)}
                      className="w-full bg-black border border-slate-800 rounded-xl px-5 py-4 text-white focus:ring-2 focus:ring-indigo-500/50 outline-none"
                      placeholder="ghp_xxxx"
                    />
                  </div>
                </div>
              </div>

              {syncStatus.msg && (
                <div className={`p-5 rounded-2xl text-[10px] font-bold flex items-start gap-4 animate-in zoom-in-95 ${syncStatus.type === 'success' ? 'bg-green-500/10 text-green-400 border border-green-500/20' : 'bg-red-500/10 text-red-400 border border-red-500/20'}`}>
                  {syncStatus.type === 'success' ? <CheckCircle2 className="shrink-0" size={18} /> : <AlertTriangle className="shrink-0" size={18} />}
                  <div className="space-y-2">
                    <p>{syncStatus.msg}</p>
                    {syncStatus.type === 'error' && syncStatus.msg.includes('পারমিশন') && (
                      <a href="https://github.com/settings/tokens/new" target="_blank" className="inline-flex items-center gap-2 text-indigo-400 hover:underline">
                        টোকেন পারমিশন ঠিক করুন <ExternalLink size={10} />
                      </a>
                    )}
                  </div>
                </div>
              )}

              <button 
                onClick={handleGlobalSync}
                disabled={isSyncing}
                className="w-full p-5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl font-black flex items-center justify-center gap-4 shadow-xl transition-all active:scale-[0.98] disabled:opacity-50 uppercase tracking-[0.2em] text-[11px]"
              >
                {isSyncing ? <Loader2 className="animate-spin" size={18} /> : <RefreshCw size={18} />}
                {isSyncing ? 'Synchronizing with GitHub...' : 'Activate Global Key'}
              </button>
            </div>
          )}

          {activeTab === 'users' && (
            <div className="text-center py-12 space-y-6">
              <div className="w-20 h-20 bg-indigo-500/10 rounded-[2rem] mx-auto flex items-center justify-center text-indigo-500 shadow-inner">
                <Users size={32} />
              </div>
              <h3 className="text-xl font-black text-white uppercase">User Access Control</h3>
              <div className="p-6 bg-slate-800/40 rounded-3xl border border-slate-700 max-w-sm mx-auto text-left space-y-4">
                 <div className="flex justify-between items-center">
                   <span className="text-[9px] font-black text-slate-500 uppercase">Public Access Password</span>
                   <span className="text-green-500 font-bold text-[9px] uppercase">Active</span>
                 </div>
                 <input 
                    type="text" 
                    value={settings.userAccessPassword || ''}
                    onChange={(e) => handleChange('userAccessPassword', e.target.value)}
                    className="w-full bg-black/40 border border-slate-700 rounded-xl px-4 py-3 text-white text-sm outline-none font-bold"
                  />
                  <p className="text-[9px] text-slate-500 font-medium italic text-center">
                    ইউজাররা ওয়েবসাইটে ঢোকার সময় এই পাসওয়ার্ডটি ব্যবহার করবে।
                  </p>
              </div>
            </div>
          )}

          {activeTab === 'system' && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4">
              <div className="space-y-3">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Maximum Video Size (GB)</label>
                <input 
                  type="number" 
                  value={settings.maxUploadSizeGB}
                  onChange={(e) => handleChange('maxUploadSizeGB', Number(e.target.value))}
                  className="w-full bg-black border border-slate-800 rounded-xl px-6 py-4 text-white font-bold text-lg outline-none"
                />
              </div>
              <div className="p-6 bg-slate-800/50 border border-slate-700 rounded-2xl flex justify-between items-center">
                <span className="text-[10px] font-black text-slate-500 uppercase">AI Model Architecture</span>
                <span className="text-[11px] font-black text-indigo-400 uppercase tracking-widest">Gemini 3 Pro</span>
              </div>
            </div>
          )}

        </div>

        <div className="p-8 border-t border-slate-800 bg-slate-900/50">
          <button onClick={onClose} className="w-full bg-slate-800 hover:bg-slate-700 text-white font-black py-4 rounded-2xl border border-slate-700 uppercase tracking-widest text-[10px] transition-all">
            Exit Control Panel
          </button>
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;
