
import React, { useState } from 'react';
import { GeneratedScript } from '../types';
import { User, Clock, FileText, Sparkles, Copy, Check } from 'lucide-react';

interface ScriptDisplayProps {
  script: GeneratedScript[];
  accuracy: number;
}

const ScriptDisplay: React.FC<ScriptDisplayProps> = ({ script, accuracy }) => {
  const [copied, setCopied] = useState(false);

  const getFormattedScript = () => {
    const header = `--- BDS AI SCRIPT EXPORT ---\nসঠিকতা (Accuracy): ${(accuracy * 100).toFixed(1)}%\nতারিখ: ${new Date().toLocaleString()}\n------------------------------------------------\n\n`;
    const body = script.map(line => 
      `সময়: ${line.timestamp}\nচরিত্র: ${line.character}\nআবেগ: ${line.emotion}\nসংলাপ: ${line.dialogue}\n------------------------------------------------`
    ).join('\n\n');
    return header + body;
  };

  const exportAsTxt = () => {
    const content = getFormattedScript();
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `bds_ai_script_${Date.now()}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const copyToClipboard = async () => {
    const content = getFormattedScript();
    try {
      await navigator.clipboard.writeText(content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  };

  return (
    <div className="w-full space-y-6">
      <div className="flex flex-col md:flex-row items-center justify-between p-5 bg-indigo-500/10 border border-indigo-500/20 rounded-2xl gap-4">
        <div className="flex items-center gap-3 text-indigo-400">
          <Sparkles className="animate-pulse" size={24} />
          <div>
            <span className="font-bold block text-lg">BDS AI স্ক্রিপ্ট প্রস্তুত</span>
            <span className="text-[10px] uppercase tracking-widest opacity-70 font-bold">নিশ্বাস, উহ, আহ এবং গভীর আবেগসহ</span>
          </div>
        </div>
        <div className="flex items-center gap-2 w-full md:w-auto">
          <button 
            onClick={copyToClipboard}
            className="flex-1 md:flex-none flex items-center justify-center gap-2 px-6 py-3 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl transition-all border border-slate-700"
          >
            {copied ? <Check size={18} className="text-green-400" /> : <Copy size={18} />}
            {copied ? 'কপি হয়েছে' : 'সব কপি করুন'}
          </button>
          <button 
            onClick={exportAsTxt}
            className="flex-1 md:flex-none flex items-center justify-center gap-2 px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl transition-all shadow-lg shadow-indigo-500/20"
          >
            <FileText size={18} /> TXT ডাউনলোড
          </button>
        </div>
      </div>

      <div className="space-y-6">
        {script.map((line, idx) => (
          <div key={idx} className="group relative bg-slate-900 border border-slate-800 p-8 rounded-3xl hover:border-indigo-500/40 transition-all duration-300">
            <div className="absolute top-0 right-8 -translate-y-1/2 flex items-center gap-2 px-3 py-1 bg-slate-800 border border-slate-700 rounded-full text-[10px] font-mono text-slate-400">
              <Clock size={12} />
              {line.timestamp}
            </div>
            
            <div className="space-y-4">
              <div className="flex flex-wrap items-center gap-3">
                <div className="flex items-center gap-2 px-4 py-1.5 bg-indigo-600 rounded-lg shadow-md shadow-indigo-600/10">
                  <User size={16} className="text-indigo-100" />
                  <span className="font-bold text-white uppercase tracking-tight">{line.character}</span>
                </div>
                <div className="px-4 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 border border-slate-700 text-indigo-300">
                  <span className="text-slate-500 mr-2 font-bold">আবেগ:</span>
                  {line.emotion}
                </div>
              </div>
              
              <div className="relative">
                <p className="text-xl md:text-2xl text-slate-100 leading-relaxed font-medium pl-2 border-l-4 border-indigo-500/30 py-2">
                  {line.dialogue}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ScriptDisplay;
