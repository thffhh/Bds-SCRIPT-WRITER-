
import { AppSettings } from './types';

export const DEFAULT_SETTINGS: AppSettings = {
  maxUploadSizeGB: 50,
  maxVideoLengthHours: 12,
  dailyAiLimit: 500,
  characterDetectionEnabled: true,
  emotionStrictness: 'high',
  googleVerifyEnabled: true,
  geminiModel: 'gemini-3-pro-preview', // Upgraded for longer and better scripts
  githubRepoUrl: '',
  netlifyDashboardUrl: '',
  userAccessPassword: 'bds-user-2025' // Default access key for public users
};

export const SECRET_TAP_COUNT = 5;
export const SECRET_LONG_PRESS_MS = 7000;
