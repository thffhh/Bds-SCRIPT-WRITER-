
import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult, AppSettings } from "../types";

export class GeminiService {
  private ai: GoogleGenAI;

  constructor(settings: AppSettings) {
    const apiKey = (typeof process !== 'undefined' && process.env && process.env.API_KEY) 
                   || settings.masterApiKey;
    
    if (!apiKey) {
      throw new Error("System configuration error: Administrative API key is missing. Contact owner.");
    }
    
    this.ai = new GoogleGenAI({ apiKey });
  }

  async analyzeVideoContent(
    fileData: string, 
    mimeType: string, 
    settings: AppSettings
  ): Promise<AnalysisResult> {
    // Enhanced prompt for "Boro Script" (Longer, more detailed outputs)
    const prompt = `
      ভিডিওটি অত্যন্ত গভীরভাবে বিশ্লেষণ করুন এবং একটি পূর্ণাঙ্গ, দীর্ঘ এবং সিনেমাটিক স্ক্রিপ্ট তৈরি করুন।
      
      স্ক্রিপ্টের নিয়মাবলী:
      ১. সংলাপ এবং আবেগ সম্পূর্ণ বাংলায় হতে হবে।
      ২. প্রতিটি চরিত্রের কথা বলার ধরণ এবং তাদের মনের অবস্থা (আবেগ) বিস্তারিত লিখুন।
      ৩. মানুষের স্বাভাবিক শব্দ যেমন- (দীর্ঘ নিশ্বাস, হাঁপানো, উহ, আহ, হাসির শব্দ, কান্নার স্বর) সংলাপে নিখুঁতভাবে যুক্ত করুন।
      ৪. কোনো দৃশ্য সংক্ষেপ করবেন না। ভিডিওতে যা ঘটছে তার প্রতিটি উল্লেখযোগ্য মুহূর্তের সংলাপ তৈরি করুন।
      ৫. স্ক্রিপ্টটি যেন অনেক দীর্ঘ (Long-form) হয় এবং প্রফেশনাল মুভি স্ক্রিপ্টের মতো দেখায়।
      
      আউটপুট ফরম্যাট: শুদ্ধ JSON হতে হবে।
    `;

    try {
      const response = await this.ai.models.generateContent({
        model: settings.geminiModel || 'gemini-3-pro-preview',
        contents: {
          parts: [
            { text: prompt },
            { inlineData: { data: fileData, mimeType } }
          ]
        },
        config: {
          // Reserved for detailed long responses
          thinkingConfig: { thinkingBudget: 32768 }, 
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              script: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    character: { type: Type.STRING },
                    emotion: { type: Type.STRING },
                    dialogue: { type: Type.STRING },
                    timestamp: { type: Type.STRING }
                  },
                  required: ["character", "emotion", "dialogue", "timestamp"]
                }
              },
              accuracy: { type: Type.NUMBER },
              verificationPassed: { type: Type.BOOLEAN }
            },
            required: ["script", "accuracy", "verificationPassed"]
          }
        }
      });

      const text = response.text;
      if (!text) throw new Error("AI response was empty.");
      return JSON.parse(text) as AnalysisResult;
    } catch (error: any) {
      console.error("Gemini Pro Error:", error);
      
      if (error.message?.includes("413") || error.message?.includes("too large")) {
        throw new Error("ভিডিও ফাইলটি এআই মডেলের জন্য অনেক বড়। মডেল সরাসরি ২০ এমবির বেশি ডাটা নিতে পারে না। দয়া করে ভিডিওটি ছোট করুন বা কম রেজোলিউশনে চেষ্টা করুন।");
      }
      
      throw new Error("এআই সার্ভিস বর্তমানে ব্যস্ত বা ফাইল সাইজ জনিত সমস্যা হয়েছে। দয়া করে ছোট ভিডিও দিয়ে চেষ্টা করুন।");
    }
  }
}
