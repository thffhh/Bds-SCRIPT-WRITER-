
import React, { useState, useEffect, useRef } from 'react';
import { 
  Shield, Upload, Cpu, Zap, AlertCircle, Info, Lock, 
  Trash2, DoorOpen, Key, ArrowRight, Mail, 
  Chrome, User as UserIcon, CheckCircle2, History as HistoryIcon,
  RefreshCcw, LogIn, Loader2, Server, Video, FileWarning, Settings, Globe
} from 'lucide-react';
import AdminPanel from './components/AdminPanel';
import ScriptDisplay from './components/ScriptDisplay';
import { GeminiService } from './services/geminiService';
import { DEFAULT_SETTINGS, SECRET_TAP_COUNT } from './constants';
import { AppSettings, ProcessingState, AnalysisResult, HistoryItem, User } from './types';

const App: React.FC = () => {
  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem('bds_ai_settings');
    return saved ? JSON.parse(saved) : DEFAULT_SETTINGS;
  });

  const [user, setUser] = useState<User | null>(() => {
    const saved = sessionStorage.getItem('bds_active_user');
    return saved ? JSON.parse(saved) : null;
  });

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPass, setLoginPass] = useState('');
  const [isLoginLoading, setIsLoginLoading] = useState(false);
  const [showGoogleMock, setShowGoogleMock] = useState(false);

  // Global Check: If API_KEY is injected into the system environment (Netlify/GitHub)
  const isGlobalActive = !!(typeof process !== 'undefined' && process.env && process.env.API_KEY);
  // Local Check: If Admin has set it manually in this browser
  const isLocalActive = !!settings.masterApiKey;
  
  const isConfigured = isGlobalActive || isLocalActive;
  
  const [history, setHistory] = useState<HistoryItem[]>(() => {
    const saved = localStorage.getItem('bds_script_history');
    return saved ? JSON.parse(saved) : [];
  });

  const [isAdmin, setIsAdmin] = useState(false);
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [adminKeyInput, setAdminKeyInput] = useState('');
  const [logoTaps, setLogoTaps] = useState(0);
  
  const [processing, setProcessing] = useState<ProcessingState>({
    isUploading: false,
    isAnalyzing: false,
    progress: 0,
    status: '',
    error: null,
  });
  const [result, setResult] = useState<AnalysisResult | null>(null);

  useEffect(() => {
    localStorage.setItem('bds_ai_settings', JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem('bds_script_history', JSON.stringify(history));
  }, [history]);

  const handleLogoClick = () => {
    const newTaps = logoTaps + 1;
    if (newTaps >= SECRET_TAP_COUNT) {
      setShowAdminLogin(true);
      setLogoTaps(0);
    } else {
      setLogoTaps(newTaps);
      setTimeout(() => setLogoTaps(0), 2000);
    }
  };

  const handleGmailLogin = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!loginEmail || !loginPass) {
      alert('সঠিক ইমেইল এবং পাসওয়ার্ড দিন।');
      return;
    }
    
    if (loginPass !== settings.userAccessPassword) {
      alert('ভুল এক্সেস পাসওয়ার্ড! অ্যাডমিনের সাথে যোগাযোগ করুন।');
      return;
    }

    setIsLoginLoading(true);
    setTimeout(() => {
      const newUser: User = {
        email: loginEmail,
        name: loginEmail.split('@')[0].toUpperCase(),
        isLoggedIn: true
      };
      setUser(newUser);
      sessionStorage.setItem('bds_active_user', JSON.stringify(newUser));
      setIsLoginLoading(false);
    }, 1500);
  };

  const handleGoogleAuth = () => {
    setShowGoogleMock(true);
    setTimeout(() => {
      const newUser: User = {
        email: 'user@gmail.com',
        name: 'G-USER ACCESS',
        isLoggedIn: true,
        photo: `https://api.dicebear.com/7.x/avataaars/svg?seed=Lucky`
      };
      setUser(newUser);
      sessionStorage.setItem('bds_active_user', JSON.stringify(newUser));
      setShowGoogleMock(false);
    }, 2500);
  };

  const handleLogout = () => {
    setUser(null);
    sessionStorage.removeItem('bds_active_user');
    window.location.reload();
  };

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminKeyInput === 'admin@gemini') {
      setIsAdmin(true);
      setShowAdminLogin(false);
      setAdminKeyInput('');
    } else {
      alert('ভুল অ্যাডমিন পাসওয়ার্ড!');
    }
  };

  const triggerUpload = () => {
    if (!isConfigured) {
      alert("সিস্টেম কনফিগার করা নেই। অ্যাডমিনকে এপিআই কী সেট করতে বলুন।");
      return;
    }
    fileInputRef.current?.click();
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!isConfigured) {
      setProcessing(p => ({ ...p, error: "সিস্টেম এরর: মাস্টার এপিআই কী পাওয়া যায়নি।" }));
      return;
    }

    setProcessing({ isUploading: true, isAnalyzing: false, progress: 0, status: 'ভিডিও ফাইল পড়া হচ্ছে...', error: null });
    setResult(null);

    try {
      const reader = new FileReader();
      reader.onload = async () => {
        const base64Data = (reader.result as string).split(',')[1];
        setProcessing(p => ({ ...p, isUploading: false, isAnalyzing: true, progress: 50, status: 'Gemini Pro গভীর বিশ্লেষণ করছে...' }));
        
        try {
          const gemini = new GeminiService(settings);
          const analysis = await gemini.analyzeVideoContent(base64Data, file.type, settings);
          setResult(analysis);
          setProcessing(p => ({ ...p, isAnalyzing: false, progress: 100, status: 'সম্পন্ন!' }));
        } catch (apiErr: any) {
          setProcessing(p => ({ ...p, error: apiErr.message, isAnalyzing: false, isUploading: false }));
        }
      };
      reader.readAsDataURL(file);
    } catch (err: any) {
      setProcessing(p => ({ ...p, error: "প্রসেসিং ব্যর্থ হয়েছে।", isAnalyzing: false }));
    }
  };

  if (showGoogleMock) {
    return (
      <div className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
        <div className="bg-white text-slate-900 w-full max-w-sm rounded-xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
          <div className="p-8 space-y-6 flex flex-col items-center text-center">
            <img src="https://upload.wikimedia.org/wikipedia/commons/c/c1/Google_Logo.svg" className="h-8 mb-4" alt="Google" />
            <h3 className="text-xl font-medium">BDS AI-তে সাইন-ইন করুন</h3>
            <p className="text-sm text-slate-500">অটোমেশন সিস্টেম ব্যবহারের অনুমতি দিন</p>
            <div className="w-full flex items-center gap-4 p-3 border rounded-lg hover:bg-slate-50 cursor-pointer transition-all">
              <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-600 font-bold">U</div>
              <div className="text-left">
                <p className="text-sm font-bold">User Account</p>
                <p className="text-xs text-slate-500">user@gmail.com</p>
              </div>
            </div>
            <div className="flex items-center gap-2 text-indigo-600 text-sm font-bold mt-4">
              <Loader2 className="animate-spin" size={16} />
              ভেরিফাই করা হচ্ছে...
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!user && !isAdmin) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-6 relative overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] bg-indigo-600/10 rounded-full blur-[120px] animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[500px] h-[500px] bg-purple-600/10 rounded-full blur-[120px] animate-pulse delay-1000" />
        <div className="w-full max-w-md space-y-10 relative z-10">
          <div onClick={handleLogoClick} className="flex flex-col items-center gap-4 cursor-pointer group text-center">
            <div className="p-5 bg-indigo-600 rounded-3xl shadow-2xl group-hover:scale-110 transition-all duration-500"><Cpu className="text-white" size={48} /></div>
            <h1 className="text-4xl font-black text-white uppercase tracking-tighter">BDS AI PORTAL</h1>
          </div>
          <div className="bg-slate-900/40 backdrop-blur-3xl border border-slate-800 p-10 rounded-[3rem] shadow-2xl space-y-8">
            <div className="space-y-6">
              <button onClick={handleGoogleAuth} className="w-full bg-white text-slate-900 font-bold py-4 rounded-2xl flex items-center justify-center gap-4 hover:bg-slate-100 transition-all shadow-lg text-sm">
                <Chrome size={20} className="text-red-500" />
                <span>Continue with Google</span>
              </button>
              <div className="flex items-center gap-4 py-2"><div className="h-[1px] bg-slate-800 flex-1" /><span className="text-[10px] font-black text-slate-600 uppercase tracking-widest">Or Login</span><div className="h-[1px] bg-slate-800 flex-1" /></div>
              <form onSubmit={handleGmailLogin} className="space-y-4">
                <input type="email" value={loginEmail} onChange={(e) => setLoginEmail(e.target.value)} placeholder="Gmail" className="w-full bg-black/60 border border-slate-800 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all" required />
                <input type="password" value={loginPass} onChange={(e) => setLoginPass(e.target.value)} placeholder="Access Password" className="w-full bg-black/60 border border-slate-800 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all" required />
                <button type="submit" disabled={isLoginLoading} className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-black py-4 rounded-2xl shadow-xl flex items-center justify-center gap-4 uppercase tracking-widest text-xs transition-all active:scale-95">
                  {isLoginLoading ? <Loader2 className="animate-spin" /> : <>Access Dashboard <ArrowRight size={18} /></>}
                </button>
              </form>
              <p className="text-[10px] text-center text-slate-500 font-bold uppercase tracking-wider">Default Pass: bds-user-2025</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-200">
      <header className="h-20 border-b border-slate-800 flex items-center justify-between px-6 md:px-12 bg-slate-900/60 backdrop-blur-xl sticky top-0 z-40">
        <div onClick={handleLogoClick} className="flex items-center gap-3 cursor-pointer group">
          <div className="p-2 bg-indigo-600 rounded-xl group-hover:rotate-12 transition-all duration-300"><Cpu className="text-white" size={24} /></div>
          <h1 className="text-xl font-black text-white uppercase tracking-tighter">BDS AI PRO</h1>
        </div>
        <div className="flex items-center gap-4">
          {isGlobalActive ? (
            <div className="flex items-center gap-2 px-4 py-1.5 bg-green-500/10 border border-green-500/30 rounded-full text-[10px] font-black text-green-500 uppercase tracking-widest">
              <Globe size={12} /> Global Active
            </div>
          ) : isLocalActive ? (
            <div className="flex items-center gap-2 px-4 py-1.5 bg-amber-500/10 border border-amber-500/30 rounded-full text-[10px] font-black text-amber-500 uppercase tracking-widest">
              <Lock size={12} /> Local Session Only
            </div>
          ) : (
             <div className="flex items-center gap-2 px-4 py-1.5 bg-red-500/10 border border-red-500/30 rounded-full text-[10px] font-black text-red-500 uppercase tracking-widest">
              <AlertCircle size={12} /> Offline / Not Configured
            </div>
          )}
          
          <button onClick={handleLogout} className="p-3 bg-slate-800 hover:bg-red-500/10 text-slate-400 hover:text-red-500 rounded-2xl transition-all border border-slate-700"><DoorOpen size={20} /></button>
          {isAdmin && <button onClick={() => setShowAdminLogin(true)} className="p-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl transition-all shadow-lg"><Shield size={20} /></button>}
        </div>
      </header>

      <main className="flex-1 max-w-5xl w-full mx-auto px-6 py-12 space-y-16">
        {!isConfigured && (
          <div className="p-8 bg-amber-500/10 border border-amber-500/20 rounded-[3rem] text-amber-500 flex items-center justify-between gap-6 animate-pulse">
            <div className="flex items-center gap-6">
              <Shield size={32} />
              <div>
                <p className="font-black uppercase text-sm tracking-widest">Master Configuration Required</p>
                <p className="text-xs opacity-80 leading-relaxed">
                  অ্যাডমিন হিসেবে আপনি একবার **Cloud Sync** করলে দুনিয়ার সব ইউজার অটোমেটিক সার্ভিসটি পাবে।
                </p>
              </div>
            </div>
            <button onClick={() => setShowAdminLogin(true)} className="px-6 py-3 bg-amber-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-amber-500 transition-all">Setup Global Key</button>
          </div>
        )}

        {isLocalActive && !isGlobalActive && (
          <div className="p-6 bg-blue-500/10 border border-blue-500/20 rounded-3xl text-blue-400 flex items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <Info size={20} />
              <p className="text-xs font-bold uppercase tracking-tight">আপনার ডিভাইসে কী সেট করা আছে, কিন্তু অন্যদের জন্য কাজ করবে না। Cloud Sync করুন।</p>
            </div>
            <button onClick={() => setShowAdminLogin(true)} className="px-5 py-2.5 bg-blue-600 text-white rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-blue-500 transition-all">Fix for Everyone</button>
          </div>
        )}

        <section className="text-center space-y-6">
          <div className="inline-flex items-center gap-3 px-6 py-2 rounded-full bg-indigo-500/5 border border-indigo-500/10 text-indigo-400 text-[10px] font-black tracking-widest uppercase">
            <Zap size={14} /> Gemini 3 Pro Deep Analysis
          </div>
          <h2 className="text-5xl md:text-7xl font-black text-white tracking-tight leading-[0.9]">AI Script <span className="text-slate-800">Engine.</span></h2>
        </section>

        <section className="relative max-w-3xl mx-auto">
          <input type="file" accept="video/*" ref={fileInputRef} onChange={handleFileUpload} className="hidden" />
          
          <div 
            onClick={triggerUpload}
            className={`group relative bg-slate-900/30 border-2 border-dashed border-slate-800 rounded-[4rem] p-16 md:p-24 transition-all hover:border-indigo-500/40 cursor-pointer overflow-hidden ${!isConfigured ? 'opacity-50' : ''}`}
          >
            <div className="flex flex-col items-center text-center space-y-8 relative z-10">
              <div className={`w-20 h-20 rounded-[2rem] flex items-center justify-center transition-all duration-500 ${!isConfigured ? 'bg-slate-800 text-slate-600' : 'bg-slate-800 group-hover:bg-indigo-600 text-slate-500 group-hover:text-white'}`}>
                <Upload size={32} />
              </div>
              <div>
                <p className="text-2xl font-black text-white">Upload Long Video</p>
                <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest mt-4">Max Size: 50GB | Target: Deep AI Script</p>
              </div>
            </div>
          </div>

          {(processing.isUploading || processing.isAnalyzing) && (
            <div className="mt-12 bg-slate-900/50 border border-slate-800 rounded-[3rem] p-10 animate-in zoom-in-95 duration-500">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-4"><RefreshCcw className="animate-spin text-indigo-500" size={20} /><p className="text-[11px] font-black text-white uppercase tracking-widest">{processing.status}</p></div>
                <span className="text-3xl font-black text-indigo-500 font-mono">{processing.progress}%</span>
              </div>
              <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full bg-indigo-500 rounded-full transition-all duration-1000" style={{ width: `${processing.progress}%` }} />
              </div>
            </div>
          )}
          
          {processing.error && (
            <div className="mt-8 p-6 bg-red-500/10 border border-red-500/20 rounded-3xl flex items-start gap-4 text-red-400 text-xs">
              <FileWarning size={18} className="shrink-0" />
              <p className="font-bold leading-relaxed">{processing.error}</p>
            </div>
          )}
        </section>

        {result && <ScriptDisplay script={result.script} accuracy={result.accuracy} />}
      </main>

      {showAdminLogin && (
        isAdmin ? (
          <AdminPanel settings={settings} setSettings={setSettings} onClose={() => setShowAdminLogin(false)} />
        ) : (
          <div className="fixed inset-0 z-[60] bg-slate-950/98 backdrop-blur-3xl flex items-center justify-center p-6">
            <form onSubmit={handleAdminLogin} className="bg-slate-900 border border-slate-800 w-full max-w-sm rounded-[4rem] p-10 space-y-8 shadow-4xl text-center">
              <div className="w-16 h-16 bg-indigo-500/10 rounded-[1.5rem] mx-auto flex items-center justify-center text-indigo-500 border border-indigo-500/20"><Shield size={32} /></div>
              <h2 className="text-xl font-black text-white uppercase tracking-tight">Admin Gateway</h2>
              <input type="password" value={adminKeyInput} onChange={(e) => setAdminKeyInput(e.target.value)} placeholder="Passcode" className="w-full bg-black/60 border border-slate-800 rounded-2xl px-6 py-4 text-white text-center font-bold outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all" autoFocus />
              <button type="submit" className="w-full bg-indigo-600 text-white font-black py-4 rounded-2xl uppercase tracking-widest text-[11px] shadow-xl">Authorize</button>
              <button type="button" onClick={() => setShowAdminLogin(false)} className="text-[10px] text-slate-600 uppercase tracking-widest font-black hover:text-slate-400">Exit</button>
            </form>
          </div>
        )
      )}
    </div>
  );
};

export default App;
