
export interface User {
  email: string;
  name: string;
  photo?: string;
  isLoggedIn: boolean;
}

export interface AppSettings {
  maxUploadSizeGB: number;
  maxVideoLengthHours: number;
  dailyAiLimit: number;
  characterDetectionEnabled: boolean;
  emotionStrictness: 'low' | 'medium' | 'high';
  googleVerifyEnabled: boolean;
  geminiModel: string;
  githubRepoUrl: string;
  netlifyDashboardUrl: string;
  githubToken?: string;
  userAccessPassword?: string;
  masterApiKey?: string; // স্টোর করা এপিআই কী
}

export interface ProcessingState {
  isUploading: boolean;
  isAnalyzing: boolean;
  progress: number;
  status: string;
  error: string | null;
}

export interface GeneratedScript {
  character: string;
  emotion: string;
  dialogue: string;
  timestamp: string;
}

export interface HistoryItem {
  id: string;
  date: string;
  fileName: string;
  result: AnalysisResult;
}

export interface AnalysisResult {
  script: GeneratedScript[];
  accuracy: number;
  verificationPassed: boolean;
}
