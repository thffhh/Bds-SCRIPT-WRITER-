
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

// Define process if it's missing (crucial for Netlify/Browser environments)
// Using a more robust polyfill to handle various build scenarios
if (typeof window !== 'undefined') {
  if (!(window as any).process) {
    (window as any).process = { env: {} };
  }
  // If process exists but env is missing
  if (!(window as any).process.env) {
    (window as any).process.env = {};
  }
}

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
